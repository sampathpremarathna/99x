export interface Product {
    id:number;
    productName:string;
    cartonPrice:number;
    unitPerCarton:number;
}
