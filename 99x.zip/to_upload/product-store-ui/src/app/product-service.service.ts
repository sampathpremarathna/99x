import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import {  Product } from './product';
import { Observable } from 'rxjs';
import { PriceRequestDTO } from './price-request-dto';

@Injectable({
  providedIn: 'root'
})
export class ProductServiceService {
  private url='http://localhost:8080/rest/products/';
  constructor(private http: HttpClient) { }

  getProducts(): Observable<any>{
    console.log("Called ...................");
    return this.http.get(this.url);
  }

  getProductCost(inputValues: PriceRequestDTO): Observable<any>{
    console.log("Called ...................");
    //const headers = new HttpHeaders().set('Content-Type', 'application/json; charset=utf-8');
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'}),
      withCredentials: true,
    };
    return this.http.post(this.url,{inputValues},httpOptions);
  }
  
}
