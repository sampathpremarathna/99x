import { PriceRequestDTO } from './price-request-dto';

describe('PriceRequestDTO', () => {
  it('should create an instance', () => {
    expect(new PriceRequestDTO()).toBeTruthy();
  });
});
