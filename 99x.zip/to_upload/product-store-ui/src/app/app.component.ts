import { Component } from '@angular/core';
import { ProductServiceService } from './product-service.service';
import {  Product } from './product';
import { PriceRequestDTO } from './price-request-dto';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Product-Store';
  developer = 'Nalaka';
  productList: Product[] = [];
  produtId: any;
  totalPrice:any;
  count:any;
  constructor(private prductService:ProductServiceService){
  }
  ngOnInit(){
    this.prductService.getProducts().subscribe(data => {
      this.productList = data;
    })
  }

  changeCity(e: any) {
    console.log("ProductId :"+e.target.value);
    this.produtId=e.target.value;
  }

  onKey(e:any){
    console.log("Count :"+e.target.value);
    this.count=e.target.value;
  }

  onClick(e:any){
    console.log("Getting Data"+e.target.value);
    const inputObj = new PriceRequestDTO();
    inputObj.count=this.count;
    inputObj.productId=this.produtId;
    inputObj.type="UNIT";
    this.prductService.getProductCost(inputObj).subscribe(data => {
      this.totalPrice = data;
    })
  }
}

