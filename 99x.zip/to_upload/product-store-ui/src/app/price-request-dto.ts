export class PriceRequestDTO {
    productId:number | undefined;
    count:number | undefined;
    type:string | undefined;
}
