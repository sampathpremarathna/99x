package com.nnx.shop.productstore.rest;

import com.nnx.shop.productstore.dto.PriceRequestDTO;
import com.nnx.shop.productstore.dto.PriceResponseDTO;
import com.nnx.shop.productstore.ex.ProductStoreExceptions;
import org.apache.http.HttpStatus;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class ProductControllerTest {

    @LocalServerPort
    private int port;

    @Autowired
    private TestRestTemplate restTemplate;

    private String url;


    @BeforeEach
    void setUp() {
        url ="http://localhost:" + port;
    }

    @Test
    void getProductsSuccess() {
        url = String.join("/",url,"rest/products/");
        ResponseEntity<String> productDTOResponseEntity=restTemplate.getForEntity(url,String.class);
        assertNotNull(productDTOResponseEntity.getBody());
    }

    @Test
    void getProductsOnEmpty() {
        url = String.join("/",url,"rest/products/");
        ResponseEntity<String> productDTOResponseEntity=restTemplate.getForEntity(url,String.class);
        assertEquals(HttpStatus.SC_OK,productDTOResponseEntity.getStatusCode().value());
    }


    @Test
    void getPriceForUnitsSuccess() throws ProductStoreExceptions {
        PriceRequestDTO priceRequestDTO = new PriceRequestDTO();
        priceRequestDTO.setProductId(1);
        priceRequestDTO.setType("UNIT");
        priceRequestDTO.setCount(1);
        url = String.join("/",url,"rest/products/getPrice");
        ResponseEntity<PriceResponseDTO> productDTOResponseEntity=restTemplate.postForEntity(url,priceRequestDTO,PriceResponseDTO.class);
        assertEquals(HttpStatus.SC_OK,productDTOResponseEntity.getStatusCode().value());
    }

    @Test
    void getPriceForUnitsValidationFailureOnInvalidType() throws ProductStoreExceptions {
        PriceRequestDTO priceRequestDTO = new PriceRequestDTO();
        priceRequestDTO.setProductId(1);
        priceRequestDTO.setType("AB");
        priceRequestDTO.setCount(1);
        url = String.join("/",url,"rest/products/getPrice");
        ResponseEntity<PriceResponseDTO> productDTOResponseEntity=restTemplate.postForEntity(url,priceRequestDTO,PriceResponseDTO.class);
        assertEquals(HttpStatus.SC_BAD_REQUEST,productDTOResponseEntity.getStatusCode().value());
    }

    @Test
    void getPriceForUnitsValidationFailureOnNoProductId() throws ProductStoreExceptions {
        PriceRequestDTO priceRequestDTO = new PriceRequestDTO();
        priceRequestDTO.setType("UNIT");
        priceRequestDTO.setCount(0);
        url = String.join("/",url,"rest/products/getPrice");
        ResponseEntity<PriceResponseDTO> productDTOResponseEntity=restTemplate.postForEntity(url,priceRequestDTO,PriceResponseDTO.class);
        assertEquals(HttpStatus.SC_BAD_REQUEST,productDTOResponseEntity.getStatusCode().value());
    }

    @Test
    void getPriceForUnitsValidationFailureOnInvalidCount() throws ProductStoreExceptions {
        PriceRequestDTO priceRequestDTO = new PriceRequestDTO();
        priceRequestDTO.setType("UNIT");
        priceRequestDTO.setCount(0);
        url = String.join("/",url,"rest/products/getPrice");
        ResponseEntity<PriceResponseDTO> productDTOResponseEntity=restTemplate.postForEntity(url,priceRequestDTO,PriceResponseDTO.class);
        assertEquals(HttpStatus.SC_BAD_REQUEST,productDTOResponseEntity.getStatusCode().value());
    }

    @Test
    void getPriceForUnitsValidationFailureOnNoType() throws ProductStoreExceptions {
        PriceRequestDTO priceRequestDTO = new PriceRequestDTO();
        priceRequestDTO.setCount(1);
        priceRequestDTO.setProductId(1);
        url = String.join("/",url,"rest/products/getPrice");
        ResponseEntity<PriceResponseDTO> productDTOResponseEntity=restTemplate.postForEntity(url,priceRequestDTO,PriceResponseDTO.class);
        assertEquals(HttpStatus.SC_BAD_REQUEST,productDTOResponseEntity.getStatusCode().value());
    }
}