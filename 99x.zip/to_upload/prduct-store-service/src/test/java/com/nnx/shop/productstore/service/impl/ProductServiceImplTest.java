package com.nnx.shop.productstore.service.impl;

import com.nnx.shop.productstore.model.PriceConfig;
import com.nnx.shop.productstore.dto.PriceRequestDTO;
import com.nnx.shop.productstore.ex.ProductStoreExceptions;
import com.nnx.shop.productstore.model.Product;
import com.nnx.shop.productstore.repository.ProductRepository;
import org.assertj.core.util.Lists;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Optional;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class ProductServiceImplTest {

    @Mock
    ProductRepository productRepository;

    @InjectMocks
    ProductServiceImpl productService;

    Product product;

    @BeforeEach
    void setUp() {
        PriceConfig priceConfig = new PriceConfig();
        priceConfig.setId(1);
        priceConfig.setBulkDiscount(10d);
        priceConfig.setBulkLowerLimit(3);
        priceConfig.setSingleUnitComp(30d);
        product = new Product();
        product.setId(1);
        product.setProductName("TEST");
        product.setCartonPrice(100);
        product.setUnitPerCarton(50);
        product.setPriceConfig(priceConfig);
        priceConfig.setProducts(Set.of(product));
    }

    @Test
    void getProductList() {
        Mockito.when(productRepository.findAll()).thenReturn(Lists.emptyList());
        assertNotNull(productService.getProductList());
    }

    @Test
    void getPriceForUnitsFail() throws ProductStoreExceptions {
        PriceRequestDTO priceRequestDTO = new PriceRequestDTO();
        priceRequestDTO.setProductId(1);
        priceRequestDTO.setCount(5);
        priceRequestDTO.setType("UNIT");
        Mockito.when(productRepository.findById(ArgumentMatchers.anyLong())).thenReturn(Optional.empty());
        assertThrows(ProductStoreExceptions.class,() -> productService.getPriceForUnits(priceRequestDTO));
    }

    @Test
    void getPriceForUnitsOnlyUnits() throws ProductStoreExceptions {
        PriceRequestDTO priceRequestDTO = new PriceRequestDTO();
        priceRequestDTO.setProductId(1);
        priceRequestDTO.setCount(10);
        priceRequestDTO.setType("UNIT");
        Mockito.when(productRepository.findById(ArgumentMatchers.anyLong())).thenReturn(Optional.of(product));
        assertEquals(26,productService.getPriceForUnits(priceRequestDTO).getTotal());
    }


    @Test
    void getPriceForUnitsUnitsAndOneCarton() throws ProductStoreExceptions {
        PriceRequestDTO priceRequestDTO = new PriceRequestDTO();
        priceRequestDTO.setProductId(1);
        priceRequestDTO.setCount(60);
        priceRequestDTO.setType("UNIT");
        Mockito.when(productRepository.findById(ArgumentMatchers.anyLong())).thenReturn(Optional.of(product));
        assertEquals(126,productService.getPriceForUnits(priceRequestDTO).getTotal());
    }

    @Test
    void getPriceForUnitsUnitsAndOneCartonWithDiscount() throws ProductStoreExceptions {
        PriceRequestDTO priceRequestDTO = new PriceRequestDTO();
        priceRequestDTO.setProductId(1);
        priceRequestDTO.setCount(160);
        priceRequestDTO.setType("UNIT");
        Mockito.when(productRepository.findById(ArgumentMatchers.anyLong())).thenReturn(Optional.of(product));
        assertEquals(296,productService.getPriceForUnits(priceRequestDTO).getTotal());
    }

    @Test
    void getPriceForCartonOnlyWhitoudDiscount() throws ProductStoreExceptions {
        PriceRequestDTO priceRequestDTO = new PriceRequestDTO();
        priceRequestDTO.setProductId(1);
        priceRequestDTO.setCount(1);
        priceRequestDTO.setType("CARTON");
        Mockito.when(productRepository.findById(ArgumentMatchers.anyLong())).thenReturn(Optional.of(product));
        assertEquals(100,productService.getPriceForUnits(priceRequestDTO).getTotal());
    }

    @Test
    void getPriceForCartonOnlyWhitDiscount() throws ProductStoreExceptions {
        PriceRequestDTO priceRequestDTO = new PriceRequestDTO();
        priceRequestDTO.setProductId(1);
        priceRequestDTO.setCount(1);
        priceRequestDTO.setType("CARTON");
        Mockito.when(productRepository.findById(ArgumentMatchers.anyLong())).thenReturn(Optional.of(product));
        assertEquals(100,productService.getPriceForUnits(priceRequestDTO).getTotal());
    }
}