insert into price_config(id,single_unit_comp,bulk_lower_limit,bulk_discount) values ( 1,30,3,10 );

insert into product(id,product_name,carton_price,unit_per_carton,price_config) values ( 1,'Penguin-ears',175.00,20 ,1);
insert into product(id,product_name,carton_price,unit_per_carton,price_config) values ( 2,'Horseshoe',825.00,5 ,1);
