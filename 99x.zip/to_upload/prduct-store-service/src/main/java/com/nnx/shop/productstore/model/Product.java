package com.nnx.shop.productstore.model;


import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

import java.io.Serializable;

@Entity
@Table(name = "product")
@Getter
@Setter
public class Product implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @Column
    private String productName;

    @Basic(fetch = FetchType.LAZY)
    @Column
    private double cartonPrice;

    @Basic(fetch = FetchType.LAZY)
    @Column
    private int unitPerCarton;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "price_config",nullable=false)
    PriceConfig priceConfig;
}


