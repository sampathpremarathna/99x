/*
 * Developed & copyright by lenovo
 */
package com.nnx.shop.productstore.service;

import com.nnx.shop.productstore.dto.PriceRequestDTO;
import com.nnx.shop.productstore.dto.PriceResponseDTO;
import com.nnx.shop.productstore.dto.ProductDTO;
import com.nnx.shop.productstore.ex.ProductStoreExceptions;

import java.util.List;

/**
 * @author :lenovo
 * @since :2/20/2021
 */
public interface ProductService {
    /**
     * Return List of all products available
     * @return Product List ( id and name)
     */
    public List<ProductDTO> getProductList();


    /**
     * Get price for the given units.
     * Calculate amount of cartons withing given units and single units
     * Calculate prices for single units and cartons and add relevant discounts
     * @param priceRequestDTO productId and units
     * @return PriceResponseDTO calculated total amount and message if there was an failure.
     */
    PriceResponseDTO getPriceForUnits(PriceRequestDTO priceRequestDTO)throws ProductStoreExceptions;
}
