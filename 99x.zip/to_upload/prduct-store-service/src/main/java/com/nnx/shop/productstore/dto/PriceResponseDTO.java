/*
 * Developed & copyright by lenovo
 */
package com.nnx.shop.productstore.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author :lenovo
 * @since :2/21/2021
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class PriceResponseDTO {
    double total;
    String message;
}
