/*
 * Developed & copyright by lenovo
 */
package com.nnx.shop.productstore.repository;

import com.nnx.shop.productstore.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * @author :lenovo
 * @since :2/20/2021
 */
@Repository
public interface ProductRepository extends JpaRepository<Product,Long> {
}
