/*
 * Developed & copyright by lenovo
 */
package com.nnx.shop.productstore.ex;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

/**
 * @author :lenovo
 * @since :2/21/2021
 */
@Getter
@Setter
@AllArgsConstructor
public class ProductStoreExceptions extends Exception{
    String message;
}
