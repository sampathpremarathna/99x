package com.nnx.shop.productstore.rest;

import com.nnx.shop.productstore.dto.PriceRequestDTO;
import com.nnx.shop.productstore.dto.PriceResponseDTO;
import com.nnx.shop.productstore.dto.ProductDTO;
import com.nnx.shop.productstore.ex.ProductStoreExceptions;
import com.nnx.shop.productstore.service.ProductService;
import lombok.extern.log4j.Log4j2;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@Log4j2
@RestController
@CrossOrigin(origins ="${WEB_DOMAIN}",methods = {RequestMethod.GET,RequestMethod.HEAD,RequestMethod.OPTIONS,RequestMethod.POST})
@RequestMapping("/rest/products")
public class ProductController {

    private final ProductService productService;

    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    /**
     * Get List of products
     * @return ResponseEntity with List of Products along with ProductIds and ProductNames
     */
    @GetMapping("/")
    public ResponseEntity<List<ProductDTO>> getProducts(){
       log.info("Getting Product List...............");
       return new ResponseEntity<>(productService.getProductList(), HttpStatus.OK);
    }

    /**
     * Calculate Total price for the given product and units.
     * @param priceRequestDTO Result with total and failure message if there was a failure
     * @return Entity with PriceResponseDTO
     */
    @PostMapping("/getPrice")
    public ResponseEntity<PriceResponseDTO> getPriceForUnits(@Valid @RequestBody PriceRequestDTO priceRequestDTO){
        log.info("Getting getPriceForUnits...............");
        try {
            PriceResponseDTO priceResponseDTO = productService.getPriceForUnits(priceRequestDTO);
            return new ResponseEntity<>(priceResponseDTO, HttpStatus.OK);
        }catch (ProductStoreExceptions ex){
            log.error("Error on PriceForUnits {0}",ex);
            PriceResponseDTO priceResponseDTO = new PriceResponseDTO();
            priceResponseDTO.setMessage(ex.getMessage());
            return new ResponseEntity<>(priceResponseDTO, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
