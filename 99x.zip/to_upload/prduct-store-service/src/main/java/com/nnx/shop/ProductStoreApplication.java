package com.nnx.shop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductStoreApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProductStoreApplication.class, args);
    }

}
