/*
 * Developed & copyright by lenovo
 * This class contains all the Constant parameters
 */
package com.nnx.shop.productstore.common;

/**
 * @author :lenovo
 * @since :2/21/2021
 */
public final class Contestants {
    public static final String UNITS = "UNIT";
    public static final String CARTONS = "CARTON";

    private Contestants() {
    //Prevent from creating instances
    }
}
