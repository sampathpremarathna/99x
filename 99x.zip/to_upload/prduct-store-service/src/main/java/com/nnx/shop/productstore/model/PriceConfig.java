/*
 * Developed & copyright by lenovo
 * Entity that holds discount and compensation values
 */
package com.nnx.shop.productstore.model;


import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Set;

/**
 * @author :lenovo
 * @since :2/21/2021
 */
@Entity
@Table(name = "price_config")
@Getter
@Setter
public  class PriceConfig implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    @Column
    private  double singleUnitComp;

    @Column
    private  int bulkLowerLimit;

    @Column
    private  double bulkDiscount;

    @OneToMany(mappedBy="priceConfig")
    private Set<Product> products;

}
