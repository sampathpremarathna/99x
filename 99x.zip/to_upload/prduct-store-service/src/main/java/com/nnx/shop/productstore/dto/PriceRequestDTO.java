/*
 * Developed & copyright by lenovo
 */
package com.nnx.shop.productstore.dto;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

/**
 * @author :lenovo
 * @since :2/21/2021
 */
@Getter
@Setter
public class PriceRequestDTO {
    long productId;
    @Min(1)
    int count;
    @NotBlank
    @Pattern(regexp = "^(UNIT|CARTON)$")
    String type;
}
