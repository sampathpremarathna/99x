/*
 * Developed & copyright by nalaka
 */
package com.nnx.shop.productstore.service.impl;

import com.nnx.shop.productstore.common.Contestants;
import com.nnx.shop.productstore.dto.PriceRequestDTO;
import com.nnx.shop.productstore.dto.PriceResponseDTO;
import com.nnx.shop.productstore.dto.ProductDTO;
import com.nnx.shop.productstore.ex.ProductStoreExceptions;
import com.nnx.shop.productstore.model.PriceConfig;
import com.nnx.shop.productstore.model.Product;
import com.nnx.shop.productstore.repository.ProductRepository;
import com.nnx.shop.productstore.service.ProductService;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @author :nalaka
 * @since :2/20/2021
 */
@Log4j2
@Service
public class ProductServiceImpl implements ProductService {

    private final ProductRepository productRepository;

    public ProductServiceImpl(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    /**
     * {@inheritDoc}
     */
    @Transactional(readOnly = true)
    @Override
    public List<ProductDTO> getProductList() {
        return productRepository.findAll().stream().map(this::getProductDTOForProduct).collect(Collectors.toList());
    }

    /**
     * {@inheritDoc}
     */
    @Transactional(readOnly = true)
    @Override
    public PriceResponseDTO getPriceForUnits(PriceRequestDTO priceRequestDTO) throws ProductStoreExceptions {
        PriceResponseDTO priceResponseDTO = new PriceResponseDTO();
        Optional<Product> productOptional = productRepository.findById(priceRequestDTO.getProductId());
        if (productOptional.isPresent()) {
            Product p = productOptional.get();
            PriceConfig priceConfig = p.getPriceConfig();
            double total;
            if(priceRequestDTO.getType().equals(Contestants.UNITS)) {
                int requestCartons = priceRequestDTO.getCount() / p.getUnitPerCarton();
                log.info("Cartons :{}", requestCartons);
                if (requestCartons > 0) {
                    double cartonTotal = getCartonTotal(p, priceConfig, requestCartons);
                    log.info("Remain Units 1s :{}", priceRequestDTO.getCount() % p.getUnitPerCarton());
                    double remainTotal = priceForSingleUnits(priceRequestDTO.getCount() % p.getUnitPerCarton(), p);
                    total = cartonTotal + remainTotal;
                } else {
                    total = priceForSingleUnits(priceRequestDTO.getCount(), p);
                }
            }else{
                total = getCartonTotal(p, priceConfig, priceRequestDTO.getCount());
            }
            priceResponseDTO.setTotal(total);
        } else {
            log.warn("Requested Product:{} not found", priceRequestDTO.getProductId());
            throw new ProductStoreExceptions("Product Not found");
        }

        return priceResponseDTO;
    }

    private double getCartonTotal(Product p, PriceConfig priceConfig, int requestCartons) {
        double cartonTotal = requestCartons * p.getCartonPrice();
        if (requestCartons >= priceConfig.getBulkLowerLimit()) {
            cartonTotal = cartonTotal - (cartonTotal * priceConfig.getBulkDiscount() / 100);
        }
        return cartonTotal;
    }

    private double priceForSingleUnits(int units, Product p) {
        double total;
        double unitPrice = p.getCartonPrice()/ p.getUnitPerCarton();
        log.info("unit price :{}",unitPrice);
        total = units*unitPrice;
        log.info("compVal :{}",p.getPriceConfig().getSingleUnitComp());
        total = total + (total*p.getPriceConfig().getSingleUnitComp()/100);
       return total;
    }

    private ProductDTO getProductDTOForProduct(Product p) {
        ProductDTO productDTO = new ProductDTO();
        productDTO.setId(p.getId());
        productDTO.setProductName(p.getProductName());
        productDTO.setCartonPrice(p.getCartonPrice());
        productDTO.setUnitPerCarton(p.getUnitPerCarton());
        return productDTO;
    }

}
